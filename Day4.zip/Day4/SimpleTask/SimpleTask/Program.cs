﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace SimpleTask
{
    class Program
    {
        static void Main(string[] args)
        {
            Task.Run(new Action(Method1));
            Task.Run(new Action(Method2));

            Console.WriteLine("Control returned to a main Program");

            Console.ReadLine();
        }

        static void Method1()
        {
            for (int i = 0; i < 10; i++)
            {
                Thread.Sleep(1000);
                Console.WriteLine("i from method1 " + i);
            }
        }


        static void Method2()
        {
            for (int i = 0; i < 10; i++)
            {
                Thread.Sleep(1000);
                Console.WriteLine("i from method2 " + i);
            }
        }
    }
}
