﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsyncMultithreadingDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //delegate without any i/p parameter or return type
            //delegate declared using Action will never have return type
            //Action Delegate
            Action del1 = delegate ()
            {
                Console.WriteLine("del1 is called..");
            };

            del1();

            Action<int, string> del2 = (int x, string name) =>
            {
                Console.WriteLine("del2 is called..");
            };

            /**************************/

            //Function Delegate -int output parameter, if we have multiple parameters passed, last one is default out
            del2.Invoke(10, "Pranav");

            Func<int> fdel1 = () => 
            {
                return 100;
            };

            Func<int, string> fdel2 = (int x) =>
            {
                return "Value";
            };

            /**************************************/
            //Predicate delegate always return boolean
            Predicate<int> pdel1 = (int z) => z == 100;
            bool result = pdel1(100);            
        }
    }
}
