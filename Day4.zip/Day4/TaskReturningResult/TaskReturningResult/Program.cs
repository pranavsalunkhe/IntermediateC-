﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace TaskReturningResult
{
    class Program
    {
        static void Main(string[] args)
        {
            callerMethod();

            Console.ReadLine();
        }

        static async void callerMethod()
        {
            Task<int> task = Task.Run(() => LongRunningMethod());

            //Task.Run(() => { LongRunningTask(); }); //we can use this syntax as well, Lambda Expression
            DoOtherStuff();
            await task; //await only works with async method, hence we declared callermethod as async

            int data = task.Result;
            DependentMethod(data); //this will wait till longrunningtask finishes its execution


        }

        private static void DependentMethod(int i)
        {
            Console.WriteLine("Data returned from the task is " +i);
        }

        //Return a task which is having value of int
        static Task<int> LongRunningMethod()
        {
            Console.WriteLine("Long running task has started");
            for (int i = 0; i < 10; i++)
            {
                Thread.Sleep(1000);
            }

            Console.WriteLine("Done with long running task");

            return Task.Run(() => 300);
        }

        static void DoOtherStuff()
        {
            Console.WriteLine("Do some other work");
        }
    }
}
