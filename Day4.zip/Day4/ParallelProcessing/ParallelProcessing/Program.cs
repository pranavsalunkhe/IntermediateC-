﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ParallelProcessing
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> intList = new List<int>();

            intList.Add(100);
            intList.Add(200);
            intList.Add(300);
            intList.Add(400);
            intList.Add(500);
            intList.Add(600);

            Parallel.For(0, intList.Count, (i) => Console.WriteLine(intList[i])); //using for i will act as an index

            Parallel.ForEach(intList, (i) => Console.WriteLine(i)); //using forreach i will act as an element 

            Console.ReadLine();
        }
    }
}
