﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace SyncProgrammingDemo
{
    class syncProg
    {
        static void Main(string[] args)
        {
            //Method1(); //Async execution
            //Method2();

            Thread thread1 = new Thread(Method1); //sync exexution
            thread1.Start();

            thread1.Join(); //join will wait until thread1 service its execution

            Thread thread2 = new Thread(Method2);            
            thread2.Start();


            Console.ReadLine();
        }


        static void Method1()
        {
            for (int i = 0; i < 20; i++)
            {
                Thread.Sleep(1000);
                Console.WriteLine("i from method1 " + i);
            }
        }


        static void Method2()
        {
            for (int i = 0; i < 20; i++)
            {
                Thread.Sleep(1000);
                Console.WriteLine("i from method2 " + i);
            }
        }
    }
}
