﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParallelProcessing2
{
    class Program
    {
        //Parallel for loop is faster than regular for loop
        //When we have bigger loop at that time we should use Parallel for loop
        static void Main(string[] args)
        {
            #region Parallel Programing using LINQ

            //while (true)
            //{
            //    Stopwatch sw1 = Stopwatch.StartNew();
            //    var list1 = (from n in Enumerable.Range(0, 5000000)
            //                 where IsPrime(n)
            //                 select n).ToList();
            //    Console.WriteLine("Required timespan in Sequencial Execution : " + sw1.Elapsed);

            //    Stopwatch sw2 = Stopwatch.StartNew();
            //    var list2 = (from n in Enumerable.Range(0, 5000000).AsParallel()
            //                 where IsPrime(n)
            //                 select n).ToList();
            //    Console.WriteLine("Required timespan in Parallel Execution : " + sw2.Elapsed);

            //    Console.ReadLine();
            //}

            #endregion

            #region Parallel Programing without LINQ

            while (true)
            {
                Stopwatch sw1 = Stopwatch.StartNew();
                Queue<int> primeNumbers1 = new Queue<int>();
                for (int i = 0; i < 5000000; i++)
                {
                    if (IsPrime(i))
                        primeNumbers1.Enqueue(i);
                }
                Console.WriteLine("Required timespan in Sequencial Execution by using manual loop : \n" + sw1.Elapsed);

                Stopwatch sw2 = Stopwatch.StartNew();
                Queue<int> primeNumbers2 = new Queue<int>();
                Parallel.For(0, 5000000, i =>
                {
                    if (IsPrime(i))
                        primeNumbers2.Enqueue(i);
                });
                Console.WriteLine("Required timespan in Parallel Execution by using Parallel loop : \n" + sw2.Elapsed);

                Console.ReadLine();
            }
            #endregion

        }

        static bool IsPrime(int number)
        {
            if (number < 2) return false;
            int bound = (int)Math.Sqrt(number);
            for (int i = 2; i <= bound; i++)
            {
                if (number % i == 0)
                    return false;
            }
            return true;
        }

        static TimeSpan Time(Action action)
        {
            Stopwatch sw = Stopwatch.StartNew();
            action();
            return sw.Elapsed;
        }
    }
}