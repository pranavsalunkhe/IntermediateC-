﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SimpleTask1
{
    class Program
    {
        static void Main(string[] args)
        {
            callerMethod();

            Console.ReadLine();
        }

        static async void callerMethod()
        {
            Task task = Task.Run(new Action(LongRunningTask));

            //Task.Run(() => { LongRunningTask(); }); //we can use this syntax as well, Lambda Expression
            DoOtherStuff();
            await task; //await only works with async method, hence we declared callermethod as async
            

            DependentMethod(); //this will wait till longrunningtask finishes its execution


        }

        private static void DependentMethod()
        {
            Console.WriteLine("Call Dependent Method");
        }

        static void LongRunningTask()
        {
            Console.WriteLine("Long running task has started");
            for (int i =0;i<10;i++)
            {
                Thread.Sleep(1000);
            }

            Console.WriteLine("Done with long running task");
        }

        static void DoOtherStuff()
        {
            Console.WriteLine("Do some other work");
        }
    }
}
