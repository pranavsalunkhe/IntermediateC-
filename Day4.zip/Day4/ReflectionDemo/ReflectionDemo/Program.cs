﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Assembly MathsLibDll = Assembly.LoadFrom(@"C:\Users\Administrator\Desktop\Intermediate C#\Day4\MathsLib\MathsLib\bin\Debug\MathsLib.dll");

                //Get types from assembly - Constructors, classes, methods etc
                GetTypes(MathsLibDll); // It will give highest level class name

                //Get Specific type from dll
                Type type = MathsLibDll.GetType("MathsLib.UMaths");

                //GetMethod(type);
                //GetConstructor(type);


                Object obj = Activator.CreateInstance(type); //creating instance of this class
                MethodInfo method = type.GetMethod("Add"); //Finding method from MathsLib.UMaths
                Console.WriteLine(method.Name);

                //Invoking above methods

                object[] param = new object[] { 10, 20 };
                object result = method.Invoke(obj, param);

                Console.WriteLine(result);



                Console.ReadLine();

            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }           
        }

        static void GetTypes(Assembly MathsLibDll)
        {
            Type[] types = MathsLibDll.GetTypes();

            foreach(Type type in types)
            {
                Console.WriteLine(type);
            }
        }

        static void GetConstructor(Type type)
        {
            ConstructorInfo[] constructors = type.GetConstructors();

            foreach (ConstructorInfo info in constructors)
            {
                Console.WriteLine(info);
            }
        }

        static void GetMethod(Type type)
        {
            MethodInfo[] methods = type.GetMethods();

            foreach(MethodInfo info in methods)
            {
                Console.WriteLine(info);
            }
        }
    }
}
