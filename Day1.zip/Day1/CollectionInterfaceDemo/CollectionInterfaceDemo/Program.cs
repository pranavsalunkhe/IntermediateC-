﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionInterfaceDemo
{
    class Employee : IComparable, IComparer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Salary { get; set; }

        public int Compare(object x, object y)
        {
            Employee emp1 = (Employee)x;
            Employee emp2 = (Employee)y;

            if (emp1.Id < emp2.Id)
                return -1;
            else if (emp1.Id > emp2.Id)
                return 1;
            else
                return 0;
        }

        public int CompareTo(object obj)
        {
            Employee emp = obj as Employee;

            if (this.Salary < emp.Salary)
                return -1;
            else if (this.Salary > emp.Salary)
                return 1;
            else
                return 0;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<int> list = new List<int>();

            list.Add(10);
            list.Add(20);
            list.Add(40);
            list.Add(60);
            list.Add(50);
            list.Add(30);

            list.Sort();

            Console.WriteLine("Sorted int list is : ");
            foreach (var v in list)
            {
                Console.WriteLine(v);
            }

            List<Employee> empList = new List<Employee>();

            empList.Add(new Employee() { Id = 1, Name = "Pranav", Salary = 50000 });
            empList.Add(new Employee() { Id = 2, Name = "Ashish", Salary = 70000 });
            empList.Add(new Employee() { Id = 3, Name = "Ujwal", Salary = 30000 });

            Console.WriteLine("Sorted Employee List using CompareTo: ");

            empList.Sort();

            foreach (Employee empp in empList)
            {
                Console.WriteLine(empp.Id + " " + empp.Name + " " + empp.Salary);
            }

            List<Employee> empList2 = new List<Employee>();



            Employee emp3 = new Employee() { Id = 1, Name = "Pranav", Salary = 50000 };
            Employee emp4 = new Employee() { Id = 2, Name = "Ashish", Salary = 70000 };

            empList2.Add(emp3);
            empList2.Add(emp4);

            Console.WriteLine("Comparison sort result is "+emp3.Compare(emp3, emp4));

            Console.WriteLine("Sorted Employee List using compare: ");            

            foreach (Employee emppp in empList2)
            {
                Console.WriteLine(emppp.Id + " " + emppp.Name + " " + emppp.Salary);
            }

            Console.ReadLine();

        }
    }
}
