﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace MemoryStreamDemo
{
    //In filestream we read data from file but in memorystream we read data in form of bytes from memory
    class Program
    {
        static void Main(string[] args)
        {
            //Reading from memory stream
            //byte[] bytearray = File.ReadAllBytes("C:\\temp\\memstream.txt");

            //using (MemoryStream memstream = new MemoryStream(bytearray))
            //{
            //    using (StreamReader reader = new StreamReader(memstream))
            //    {
            //        while(!reader.EndOfStream)
            //        {
            //            Console.WriteLine(reader.ReadLine());
            //        }
            //    }
            //}

            //Write data using memory stream

            using (MemoryStream mstream = new MemoryStream())
            {
                using (StreamWriter writer = new StreamWriter(mstream))
                {
                    writer.WriteLine("1234");
                    writer.WriteLine("C#");
                    writer.WriteLine("Pranav");

                    writer.Flush(); //in case of memory stream ,while writing we have to use flush explicitely

                    using (FileStream fstream = new FileStream("C:\\temp\\memwrite14.txt", FileMode.Append))
                    {
                        mstream.WriteTo(fstream);
                    }
                        
                }
            }

            //Console.ReadLine();
        }
    }
}
