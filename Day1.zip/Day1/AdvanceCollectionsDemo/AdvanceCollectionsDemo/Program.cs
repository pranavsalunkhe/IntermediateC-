﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdvanceCollectionsDemo
{

    class Employee
    {
        public int Id { get; set; }
        public string Address { get; set; }
    }

    /*class CustomCollection
    {
        int counter;
        public List<int> list1 = new List<int>();

        public void Push( int item)
        {
            list1.Add(item);
            counter++;
        }

        public int Pop()
        {
            counter = counter - 1;
            return list1[counter];
        }
    }*/

    class CustomCollection<T> //Generic class
        {
            int counter;
            public List<T> list1 = new List<T>();

            public void Push( T item)
            {
                list1.Add(item);
                counter++;
            }

            public T Pop()
            {
                counter = counter - 1;
                return list1[counter];
            }
        }

    class CustomList<T>
    {
        List<T> list2 = new List<T>();

        public void Push2(T item)
        {
            list2.Add(item);
        }

        public T Prev(T value)
        {
            int iIndex = list2.IndexOf(value);

            if (iIndex > 0)
            {
                return list2[iIndex - 1];
            }
            else
                return default(T);
        }

        public T Next(T value)
        {
            int iIndex = list2.IndexOf(value);

            if (iIndex < list2.Count)
            {
                return list2[iIndex + 1];
            }
            else
                return default(T);
        }
    }
    


    //Types of collections: 1. Generic - List<>, Dictionary<>, Stack<>, Queue<> 2. Non Generic - Array, ArrayList, Hashtable, Stack, Queue
    //CustomGeneric
    class Program
    {
        static void Main(string[] args)
        {
            //CustomCollection<int> custom1 = new CustomCollection<int>(); //while creating an object we will decide int or string or any othet type
            //custom1.Push(10);
            //custom1.Push(20);
            //custom1.Push(30);
            //custom1.Push(40);

            //Console.WriteLine(custom1.Pop());
            //Console.WriteLine(custom1.Pop());

            //CustomCollection<string> custom2 = new CustomCollection<string>(); //This is of type string

            //custom2.Push("C#");
            //custom2.Push("Java");
            //custom2.Push("Python");
            //custom2.Push("VB");

            //Console.WriteLine(custom2.Pop());
            //Console.WriteLine(custom2.Pop());

            //CustomCollection<Employee> custom3 = new CustomCollection<Employee>(); //This is of type Employee object

            //custom3.Push(new Employee() {Id = 1, Address = "Pune" });
            //custom3.Push(new Employee() { Id = 2, Address = "Mumbai" });
            //custom3.Push(new Employee() { Id = 3, Address = "Shirpur" });
            //custom3.Push(new Employee() { Id = 4, Address = "Dhule" });

            //Employee emp1 = custom3.Pop();
            //Employee emp2 = custom3.Pop();

            //Console.WriteLine(emp1.Id +" "+ emp1.Address);
            //Console.WriteLine(emp2.Id + " " + emp2.Address); 

            CustomList<int> intList = new CustomList<int>();

            intList.Push2(100);
            intList.Push2(200);
            intList.Push2(300);
            intList.Push2(400);

            Console.WriteLine(intList.Prev(200));
            Console.WriteLine(intList.Next(200));


            CustomList<string> stringList = new CustomList<string>();

            stringList.Push2("C#");
            stringList.Push2("VB");
            stringList.Push2("Java");
            stringList.Push2("Python");

            Console.WriteLine(stringList.Prev("Java"));
            Console.WriteLine(stringList.Next("Java"));


            Console.ReadLine();
        }
    }
}
