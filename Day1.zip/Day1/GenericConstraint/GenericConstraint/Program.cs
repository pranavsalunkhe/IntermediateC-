﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericConstraint
{

    class Employee
    {

    }

    //class constrain will work with only ref type 
    class CustomFiltersClass<T> where T: class
    {
        public void FilterClass()
        {

        }
    }

    //struct constrain will work with only ref type 
    class CustomFiltersStruct<T> where T : struct
    {
        public void FilterStruct()
        {

        }
    }

    // Employee/class specific constrain
    class CustomFiltersEmployee<T> where T : Employee
    {
        public void FilterEmployee()
        {

        }
    }

    //new(): classes/structs which have parameterless constructore
    class CustomFiltersNew<T> where T : new()
    {
        public void FilterNew()
        {

        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            CustomFiltersClass<Employee> custom1 = new CustomFiltersClass<Employee>(); // this is class constrain, accepting only ref type
            CustomFiltersStruct<int> custom2 = new CustomFiltersStruct<int>(); // this is struct constrain, accepting only value type, not ref type (not even string)
            CustomFiltersEmployee<Employee> custom3 = new CustomFiltersEmployee<Employee>(); // this is Employee constrain, accepting only Employee reference
            CustomFiltersNew<int> custom4 = new CustomFiltersNew<int>(); //for new()
        }
    }
}
