﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpecializedCollectionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Below things are useful in the case of performance tuning

            //Hashtable - This is normal hashtable
            Hashtable ht = new Hashtable();
            ht.Add("Key1", "Value1");
            ht.Add("Key2", "Value2");
            ht.Add("Key3", "Value3");

            //1. ListDictionary - need system.specialized namespace to be added
            //Similar to hashtable but efficient when we have less than 10 elements.
            ListDictionary dict1 = new ListDictionary();
            dict1.Add("key1", "value1");
            dict1.Add("key2", "value2");
            dict1.Add("key3", "value3");

            //2. HybridDictionary = ListDictionary + HashTable

            HybridDictionary hd = new HybridDictionary();
            hd.Add("Key1", "Value1");
            hd.Add("Key2", "Value2");
            hd.Add("Key3", "Value3");

            //3. StringCollection
            //List<string> - generic collection of arraylist with string type
            StringCollection str = new StringCollection();
            str.Add("abc");
            str.Add("pqr");

            //4. StringDictionary
            //List<string, string> - generic collection of dictionary with string type
            StringDictionary strd = new StringDictionary();
            strd.Add("key1", "value1");
            strd.Add("key2", "value2");

            //5. NameValueCollection - it can accept same key and accept string only - all values related to same key will be retrieved as a comma separated string
            NameValueCollection nmv = new NameValueCollection();
            nmv.Add("System", "xml");
            nmv.Add("System", "json");
            nmv.Add("System", "file");
            nmv.Add("System.io", "filestream");
            nmv.Add("System.io", "binarystream");

            string strValue = nmv["System"];

            Console.WriteLine(strValue);

            //6. OrderedDictionary - print elements sequentially in a given order/ added order
            OrderedDictionary od = new OrderedDictionary();
            od.Add(1, "abc");
            od.Add(2, "pqr");
            od.Add(3, "xml");
            od.Add(4, "lmn");

            foreach (DictionaryEntry dict in od)
            {
                Console.WriteLine(dict.Key+" "+dict.Value);
            }

            Console.ReadLine();

        }
    }
}
