﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericMethodDemo
{
    class SwapUtility
    {
        public static void Swap<T>(ref T item1, ref T item2)
        {
            T tempItem = item1;
            item1 = item2;
            item2 = tempItem;

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int num1 = 100;
            int num2 = 200;
            SwapUtility.Swap<int>(ref num1, ref num2); // Passing as reference, value type will retain original values

            Console.WriteLine("Num1: "+num1+" Num2: "+num2);
            

            string name1 = "C#";
            string name2 = "Java";

            SwapUtility.Swap<string>(ref name1, ref name2); // Passing as reference, value type will retain original values

            Console.WriteLine("Name1: " + name1 + " Name2: " + name2);

            Console.ReadLine();
        }
    }
}
