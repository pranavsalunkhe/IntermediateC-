﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymusDelegateDemo
{
    delegate void anonymusDelegate(string name);
    delegate int anonymusDelegate1();

    class Program
    {
        static void Main(string[] args)
        {
            //we didn't wrote method separately, instead we wrote method within delegate like below
            //This is used when we just want our delegate to use certain method only
            anonymusDelegate delg1 = delegate (string name)
            {
                Console.WriteLine("Delegate without method/ method within delegate has been called : " + name);
            };

            delg1("Pranav");

            anonymusDelegate1 delg2 = delegate ()
            {
                return 100;
            };
            Console.WriteLine(delg2());

            Console.ReadLine();
        }
    }
}
