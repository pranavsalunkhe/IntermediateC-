﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventDemo
{
    delegate void DelAmountDeposit(int Amount);

    class BankAccount
    {
        //defining an event for above delegate
        public event DelAmountDeposit AmountDepositEvent;

        public void AmountDeposit(int Amount)
        {
            //Raising an event
            if(AmountDepositEvent != null)
            {
                AmountDepositEvent(Amount);
            }
            
        }
        public void AmountWithdraw(int Amount)
        {

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            BankAccount account = new BankAccount();
            int Amount = 1000;
            account.AmountDepositEvent += new DelAmountDeposit(SendSMS);
            account.AmountDepositEvent += new DelAmountDeposit(SendEmail);
            account.AmountDeposit(Amount);

            Console.ReadLine();

        }

        static void SendSMS (int Amount)
        {
            Console.WriteLine("SendSMS called");
        }

        static void SendEmail(int Amount)
        {
            Console.WriteLine("SendEmail called");
        }
    }
}
