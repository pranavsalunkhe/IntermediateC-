﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleDelegateDemo
{
    class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public double Salary { get; set; }
    }

    class Program
    {
        //Delegates: pointer to a method
        //using delegate we can pass method as a parameter
        //we can call multiple methods through delegate
        //pass method as par to delegate which return type and parameters are same
        //we can declare anywhere, inside the class or outside the class as well
        delegate void delegate1(int a, int b);

        delegate void PromoteDelegate();

        static void Main(string[] args)
        {
            List<Employee> empList = new List<Employee>();

            empList.Add(new Employee() { Id = 100, Name = "Pranav", Address = "Pune", Salary = 54656 });
            empList.Add(new Employee() { Id = 200, Name = "ABC", Address = "Mumbai", Salary = 65655 });
            empList.Add(new Employee() { Id = 300, Name = "ABC", Address = "Nasil", Salary = 89855 });

            //delegate1 del1 = new delegate1(add);
            //del1(10, 20);
            ////del1.Invoke(10, 20); this also works - other syntax

            PromoteDelegate promoteDelegateBySalary = new PromoteDelegate(DoPromotionBySalary);
            promoteDelegateBySalary += new PromoteDelegate(DoPromotionByExp); //This also works if we comment below instance
            PromoteEmployees(empList, promoteDelegateBySalary);

            //This is also correct - unicast delegate
            //PromoteDelegate promoteDelegateByExp = new PromoteDelegate(DoPromotionByExp);
            //PromoteEmployees(empList, promoteDelegateByExp);

            Console.ReadLine();
        }

        static void PromoteEmployees(List<Employee> empList, PromoteDelegate delg)
        {
            foreach(var emp in empList)
            {
                delg();
            }
        }

        static void DoPromotionBySalary()
        {

        }

        static void DoPromotionByExp()
        {

        }

        static void add(int a, int b)
        {
            int result = a + b;
            Console.WriteLine("Add is called and result of "+a+" and "+b+" addition is "+ result);
        }
    }
}
