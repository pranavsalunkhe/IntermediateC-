﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnicastDelegateDemo
{
    delegate int Calculate(int a, int b);
    class Program
    {
        static void Main(string[] args)
        {
            Calculate delCal = new Calculate(add);
            Console.WriteLine(delCal(10, 20));

            Console.ReadLine();
        }

        static int add(int a, int b)
        {
            return a + b;
        }
    }
}
