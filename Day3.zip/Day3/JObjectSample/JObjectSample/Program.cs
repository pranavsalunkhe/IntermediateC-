﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JObjectSample
{
    class Program
    {
        
        static void Main(string[] args)
        {
            //JObject1();
            //JObject2();
            //JArray1();
            VarDynamicDemo();
            Console.ReadLine();
        }

        static void JObject1()
        {
            string jSon1 = @"{'productName':'TV', 'prodId':'123'}";
            JObject jObject = JObject.Parse(jSon1);

            Console.WriteLine(jObject["productName"]);
            Console.WriteLine(jObject["prodId"]);           

        }

        static void JObject2()
        {
            string json = @"{
                ""Name"": ""Apple"",
                ""Expiry"": new Date(1230422400000),
                ""Price"": 3.99,
                ""Sizes"": [
                    ""Small"",
                    ""Medium"",
                    ""Large""
                ]
            }";

            //JObject works on key value pair - When we dont have class, please use Jobject
            JObject obj1 = JObject.Parse(json);

            Console.WriteLine(obj1["Name"]);
            Console.WriteLine(obj1["Expiry"]);
            Console.WriteLine(obj1["Price"]);
            Console.WriteLine(obj1["Sizes"][0]);        //This is array hence accessed using its index
            Console.WriteLine(obj1["Sizes"][1]);        //Array can also be a valid Json
            Console.WriteLine(obj1["Sizes"][2]);

        }

        //When we have array string at that time we use JArray class i.e., Array of JObjects
        static void JArray1()
        {
            string strData1 = @"[{'name':'mukta','id':'789'},{'name':'mukta34','id':'789'}]";

            JArray jArray = JArray.Parse(strData1);            

            foreach (var v in jArray)
            {
                JObject obj2 = JObject.Parse(v.ToString());

                Console.WriteLine(obj2["name"]);
                Console.WriteLine(obj2["id"]);
            }

        }

        static void VarDynamicDemo()
        {
            //var can take data type of value assigned but we cant change data type once it is assigned
            //Eg.
            //var intVar = 100;
            //intVar = "name"; // This is not possible
            //Instead we can use Dynamic, it resolves issue at Runtime
            //Eg.
            dynamic d1 = "name";
            Console.WriteLine("type of d1: " + d1.GetType());
            d1 = 100;
            Console.WriteLine("type of d1: " + d1.GetType());

            //Even we can create dynamic objets as well

            string strData1 = @"[{'name':'mukta','id':'789'},{'name':'mukta34','id':'789'}]";
            var dynObj = JsonConvert.DeserializeObject<dynamic>(strData1);
        }
    }
}
