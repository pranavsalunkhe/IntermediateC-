﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MulticastDelegateDemo
{
    delegate int Calculate(int a, int b);
    class Program
    {
        static void Main(string[] args)
        {
            Calculate delCal = new Calculate(add);
            delCal += new Calculate(sub); //we can add delegate by this. It depends upon condition

            //delCal -= new Calculate(sub); //we can remove delegate by this. It depends upon condition

            Console.WriteLine(delCal(30, 20)); //we will get value from last method only, but call both methods
            Console.ReadLine();
        }

        static int add(int a, int b)
        {
            Console.WriteLine("Add is called");
            return a + b;
        }

        static int sub(int a, int b)
        {
            Console.WriteLine("sub is called");
            return a - b;
        }
    }
    
}
