﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ASyncDelegateDemo
{

    delegate void asyndelg1(int type);
    class AsyncDelegates
    {
        static void Main(string[] args)
        {
            //ProcessFile();

            asyndelg1 del1 = new asyndelg1(ProcessFile);
            // del1(10); //sync call
            del1.Invoke(30); // sync call


            del1.BeginInvoke(40, TaskCompleted, null); //async call
            ProcessData();
            Console.ReadLine();
        }


        private static void TaskCompleted(IAsyncResult ar)
        {
            Console.WriteLine("Work assigned to fileprocess is completed!");
        }

        static void ProcessFile(int type)
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("i " + i);
                Thread.Sleep(1000);
            }
        }

        static void ProcessData()
        {
            Console.WriteLine("processdata is called");
        }

    }


}
