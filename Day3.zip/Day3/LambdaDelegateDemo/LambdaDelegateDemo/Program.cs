﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LambdaDelegateDemo
{
    delegate void delegate1();
    delegate void delegate2(int a, int b);
    delegate int delegate3(int a);

    class Program
    {
        static void Main(string[] args)
        {
            //delegate with anonymus method
            delegate1 del1Anonymus = delegate()
            {
                Console.WriteLine("First Delegate called with anonymus method");
            };
            del1Anonymus(); //delegate called

            //delegate with lambda expressios
            delegate1 del1Lambda = () => Console.WriteLine("First Delegate called with Lambda expression delegate");
            del1Lambda.Invoke();
            

            //anonymus delegate with parameter
            delegate2 del2Anonymus = delegate (int a, int b)
            {
                Console.WriteLine("anonymus delegate with parameter called");
            };
            del2Anonymus(10, 20);

            //Lambda delegate with parameter
            delegate2 del2Lambda = (int a, int b) => { Console.WriteLine("Second Delegate with parameter called with Lambda expression delegate"); };
            del2Lambda(10, 20);

            //delagate with input parameter and return type as well with Anonymus
            delegate3 del3Anonymus = delegate (int a)
            {
                Console.WriteLine("Delegate with input parameter and return type with Anonymus delegate");
                return 100;
            };
            del3Anonymus(20);

            //delegate with input parameter and return type with Lambda

            delegate3 del3Lambda = (int a) => 
            {                
                Console.WriteLine("Delegate with input parameter and return type with Lambda expression delegate");
                return 100;
            };
            del3Lambda(100);

            Console.ReadLine();
        }
    }
}
