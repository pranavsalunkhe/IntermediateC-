﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace FileSystemWatcherDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            FileSystemWatcher watcher = new FileSystemWatcher();
            watcher.Path = @"c:\temp";

           // watcher.NotifyFilter = NotifyFilters.LastAccess | NotifyFilters.LastWrite | NotifyFilters.FileName | NotifyFilters.DirectoryName;

            watcher.Deleted += Watcher_Deleted;
            watcher.Changed += Watcher_Changed;
            watcher.Renamed += Watcher_Renamed;
            watcher.Created += Watcher_Created;

            watcher.EnableRaisingEvents = true; //this is mandatory

            //watcher.Filter = ".txt"; this is optional

            Console.ReadLine();
                
        }

        private static void Watcher_Created(object sender, FileSystemEventArgs e)
        {
            Console.WriteLine(e.Name+" is created "+e.FullPath+" "+DateTime.Now.ToString());            
        }

        private static void Watcher_Renamed(object sender, RenamedEventArgs e)
        {
            Console.WriteLine(e.OldName + " is renamed to" + e.Name+ " " + DateTime.Now.ToString());
        }

        private static void Watcher_Changed(object sender, FileSystemEventArgs e)
        {
            Console.WriteLine(e.Name + " is changed " + e.ChangeType + " " + DateTime.Now.ToString());
        }

        private static void Watcher_Deleted(object sender, FileSystemEventArgs e)
        {
            Console.WriteLine(e.Name + " is deleted " + e.FullPath + " " + DateTime.Now.ToString());
        }
    }
}
