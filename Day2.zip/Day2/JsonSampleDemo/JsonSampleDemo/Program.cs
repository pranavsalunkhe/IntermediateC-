﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JsonSampleDemo
{
    class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

    //JSON - simpler than XML and Now a days Restful web services are using JSON
    //Serialization - converting dot net object to JSON
    //Deserialization - converting JSON to dot net object
    class Program
    {
        static void Main(string[] args)
        {
            Serialize();
            Deserialize();
            Console.ReadLine();
        }

        static List<Employee> GetEmployees()
        {
            List<Employee> employeeList = new List<Employee>();
            employeeList.Add(new Employee() { Id = 10, Name = "Pranav"});
            employeeList.Add(new Employee() { Id = 11, Name = "Sonu" });

            return employeeList;
        }

        public static void Serialize()
        {
            List<Employee> emps = GetEmployees();

            string strJson = JsonConvert.SerializeObject(emps);

            Console.WriteLine(strJson);
        }

        public static void Deserialize()
        {
            string strData = @"[{'Id':10,'Name':'Pranav'},{'Id':11,'Name':'Sonu'}]";

            List<Employee> employees = JsonConvert.DeserializeObject<List<Employee>>(strData);

            foreach(var v in employees)
            {
                Console.WriteLine(v.Id + " " + v.Name);
            }
        }


    }
}
