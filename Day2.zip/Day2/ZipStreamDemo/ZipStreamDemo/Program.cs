﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZipStreamDemo
{
    class Program
    {
        //What needs for zipping the file
        //1. Source file to be zipped (FileStream) (Eg. Sample.txt)
        //2. Dest file (.zip/.gz file) (FileStream) (Eg. Sample123.zip)
        //3. GZipStream for compressing/decompressing stream
        static void Main(string[] args)
        {
            Compress();
            Decompress();

            Console.ReadLine();
        }
        static void Compress()
        {
            try
            {
                using (FileStream sourceStream = File.OpenRead(@"C:\zipping\sample.txt"))
                {
                    using (FileStream destStream = File.Create("C:\\zipping\\sample.gz"))
                    {
                        using (GZipStream zipStream = new GZipStream(destStream, CompressionMode.Compress))
                        {
                            int thebyte = sourceStream.ReadByte();

                            while (thebyte != -1)
                            {
                                zipStream.WriteByte((byte)thebyte);
                                thebyte = sourceStream.ReadByte();
                            }
                        }
                    }
                }

            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            
        }

        static void Decompress()
        {

            using (Stream fileToBeDecompress = File.OpenRead(@"c:\zipping\sample.gz"),
              decompressedFile = File.Create(@"c:\zipping\sample123.txt"),
              decompStream = new GZipStream(fileToBeDecompress, CompressionMode.Decompress))
                {
                int theByte = decompStream.ReadByte();
                while (theByte != -1)
                {
                    decompressedFile.WriteByte((byte)theByte);
                    theByte = decompStream.ReadByte();
                }
            }
            Console.WriteLine("File unzipped succesfully");
        }
    }
}
