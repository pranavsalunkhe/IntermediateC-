﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace XMLDemoWriting
{
    class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Salary { get; set; }
    }
    class Program
    {
        //DOM Parse - Dcoument Object Model - Anywhere anypint - but initially load complete XML - use extensively/ most frequently
        //SAX Parser - when we have bigger XML, read data sequentially - Get code from CLG
        static void Main(string[] args)
        {
            try
            {
                List<Employee> emp = GetEmployees();

                XmlDocument xmlDoc = new XmlDocument();

                XmlElement root = xmlDoc.CreateElement("Employees");
                xmlDoc.AppendChild(root);

                foreach (Employee emps in emp)
                {
                    //Employee node is added
                    XmlElement empNode = xmlDoc.CreateElement("Employee");

                    XmlAttribute attr =  xmlDoc.CreateAttribute("id");
                    attr.Value = emps.Id.ToString();
                    empNode.Attributes.Append(attr);
                    root.AppendChild(empNode);

                    //Adding Name node

                    XmlElement nameNode = xmlDoc.CreateElement("Name");
                    nameNode.InnerText = emps.Name;

                    empNode.AppendChild(nameNode);

                    XmlElement salaryNode = xmlDoc.CreateElement("Salary");
                    salaryNode.InnerText = emps.Salary.ToString();

                    empNode.AppendChild(salaryNode);                   

                }

                xmlDoc.Save("C:\\temp\\Employees.xml");

                Console.WriteLine("XML has been created");
            }

            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            

            Console.ReadLine();
            
        }
        
        static List<Employee> GetEmployees()
        {
            List<Employee> employeeList = new List<Employee>();
            employeeList.Add(new Employee() { Id = 10, Name = "Pranav", Salary = 10000 });
            employeeList.Add(new Employee() { Id = 11, Name = "Sonu", Salary = 20000 });

            return employeeList;
        }
    }
}
