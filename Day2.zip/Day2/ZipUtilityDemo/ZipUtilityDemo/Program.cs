﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Compression;

namespace ZipUtilityDemo
{
    class Program
    {
        public static void Main(string[] args)
        {
            // The directory will be compressed.
            string inputDir = @"C:/zipping/inputdir";

            // The output file after compressing the above directory.
            string zipPath = @"C:/zipping/sample1.gz";

            // Extract the zip file to the folder.
            string extractPath = @"C:/zipping/outputdir";

            // Create zip file by compressing a folder.
            ZipFile.CreateFromDirectory(inputDir, zipPath);

            // Extract the zip file to the folder.
            ZipFile.ExtractToDirectory(zipPath, extractPath);

            Console.WriteLine("Done!");
        }
    }
}
