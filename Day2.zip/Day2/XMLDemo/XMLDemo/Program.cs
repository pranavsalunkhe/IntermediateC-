﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace XMLDemo
{
    class Student
    {
        public int Id { get; set; } //we can take code as well
        public string Name { get; set; }
        public string Address { get; set; }
        public int Marks { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //DOM Parser
            try
            {
                //Instantiating XML Dom Parser
                XmlDocument xmlDoc = new XmlDocument();
                string strPath = Directory.GetCurrentDirectory(); //Reading XML
                strPath = strPath.Replace("bin\\Debug", "").Trim();
                strPath = strPath + "Students.xml";
                xmlDoc.Load(strPath);

                //XMLNodeList will consists of XMLNodes
                XmlNodeList nodeList = xmlDoc.SelectNodes("/Students/Student");

                List<Student> studentList = new List<Student>();

                foreach (XmlNode node in nodeList) //Traversing over XML list
                {
                    Student student = new Student();

                    student.Id = int.Parse(node.Attributes["id"].Value);

                    student.Name =  node.SelectSingleNode("Name").InnerText;
                    student.Address = node.SelectSingleNode("City").InnerText;
                    student.Marks = int.Parse(node.SelectSingleNode("Marks").InnerText);

                    studentList.Add(student);
                }

                foreach(var std in studentList)
                {
                    Console.WriteLine(std.Id+"\t"+std.Name+"\t"+std.Address+"\t"+std.Marks);
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }           

            Console.ReadLine();
        }
    }
}
