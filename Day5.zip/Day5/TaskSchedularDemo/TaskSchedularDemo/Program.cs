﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskSchedularDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteData();
        }

        static void WriteData()
        {
            try
            {
                FileStream stream = new FileStream("C:\\temp\\Log.txt", FileMode.Append);
                StreamWriter writer = new StreamWriter(stream);

                writer.WriteLine("Message written at " + DateTime.Now);

                writer.Close();
                stream.Close();
            }
            catch (Exception ex)
            {

            }
        }
    }
}
