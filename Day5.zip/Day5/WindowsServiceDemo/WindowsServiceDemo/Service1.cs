﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace WindowsServiceDemo
{
    public partial class Service1 : ServiceBase
    {
        Timer t1 = new Timer();

        public Service1()
        {
            InitializeComponent();
        }

       

        protected override void OnStart(string[] args)
        {
            WriteData("Log service is started at: " + DateTime.Now);

            t1.Elapsed += T1_Elapsed;

            t1.Interval = 5000; //in milliseconds
            t1.Enabled = true;

        }

        private void T1_Elapsed(object sender, ElapsedEventArgs e)
        {
            WriteData("Writing to file again..." + DateTime.Now);
        }

        protected override void OnStop()
        {
            WriteData("Service has been stopped at : " + DateTime.Now);
        }

        protected void WriteData(string message)
        {
            try
            {
                FileStream stream = new FileStream("C:\\temp\\Log.txt", FileMode.Append);
                StreamWriter writer = new StreamWriter(stream);

                writer.WriteLine(message);

                writer.Close();
                stream.Close();
            }
            catch (Exception ex)
            {
                
            }
        }
    }
}
