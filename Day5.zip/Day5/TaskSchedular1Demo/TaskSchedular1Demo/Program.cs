﻿using Microsoft.Win32.TaskScheduler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskSchedular1Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            using(TaskService ts = new TaskService())
            {
                TaskDefinition td = ts.NewTask();

                DailyTrigger tg = new DailyTrigger();
                tg.StartBoundary = DateTime.Now;
                tg.Repetition.Interval = TimeSpan.FromSeconds(60);

                td.Triggers.Add(tg);

                td.Actions.Add(new ExecAction("cmd.exe", null, @"C:\Users\Administrator\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\System Tools"));

                ts.RootFolder.RegisterTaskDefinition("LastTask", td);
            }
        }
    }
}
